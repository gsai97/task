Getting Started

Flipkart- Flipkart Application Coding Challenge

Java Spring Boot REST API - Spring Boot Application To Register Merchant and List Products Bases on Merchant ID

Requirements

Java JDK-1.8 or 1.8+ Spring Boot Embeded Tomcat Start local server

API's

Import the code as Maven code
Maven Build - Clean install
Start local server
Swagger URL- http://localhost:8080/swagger-ui/index.html#/
Register New Merchant - http://localhost:8080/merchant
Product List  - http://localhost:8080/product